# @mgc/ui — UI-кит MGC GROUP одним пакетом

Компоненты React, токены, темы для Tailwind и Vuetify, токены для Figma — одна установка.

```bash
npm i @mgc/ui
```

Зависимости кита (Base UI, Recharts, TanStack Table, dnd-kit, lucide и др.) ставятся вместе с пакетом.
React 19 нужен только React-проектам: Vue-проектам пакет отдаёт CSS и темы без React.

## Что внутри

| Импорт | Для чего |
|---|---|
| `@mgc/ui` | 400+ экспортов: компоненты shadcn/ui под MGC, `DataTable`, `StatCard`, `DatePicker`, `PlatformSidebar`, мобильные, `ModuleProvider`, `useIsMobile`, `cn` |
| `@mgc/ui/styles.css` | Готовые стили всех компонентов. Tailwind в проекте **не нужен** |
| `@mgc/ui/theme.css` | Тема для проектов **на Tailwind v4**: токены + утилиты (`bg-brand`, `text-module-strong`…) + компоненты кита |
| `@mgc/ui/tokens.css` | Только CSS-переменные (цвета, радиус, тени, акценты модулей). Для Vue, Vuetify и любого HTML |
| `@mgc/ui/fonts.css` | IBM Plex Sans / Mono — латиница и кириллица, файлы внутри пакета (работает без интернета) |
| `@mgc/ui/vuetify` | Темы Vuetify 2 и 3 (светлая/тёмная), цвета акцентов модулей |
| `@mgc/ui/tailwind-preset` | Пресет для проектов на Tailwind v3 |
| `@mgc/ui/figma-tokens.json` | Токены для плагина Tokens Studio в Figma |

Все цвета в `vuetify`, `tailwind-preset` и `figma-tokens.json` генерируются из `tokens.css` при сборке —
вручную их не правят.

## React без Tailwind (Vite, Next.js)

```tsx
// main.tsx / app/layout.tsx
import "@mgc/ui/styles.css"

import { Button, ModuleProvider, StatCard, Toaster } from "@mgc/ui"

export function App() {
  return (
    <ModuleProvider module="maintenance">
      <Button>Создать заявку</Button>
      <Toaster />
    </ModuleProvider>
  )
}
```

`styles.css` содержит базовые стили (сброс, фон, шрифт `body`) — подключайте один раз в корне.

## React + Tailwind v4

```css
/* globals.css */
@import "tailwindcss";
@import "@mgc/ui/theme.css";
```

Подключать `styles.css` не нужно: Tailwind проекта сам соберёт классы компонентов кита
(в `theme.css` есть `@source` на код пакета) и даст те же токены вашим разметкам:
`bg-module-soft`, `text-success`, `shadow-lg`, `font-mono`…

## Тёмная тема и акцент модуля

- Тёмная тема — класс `.dark` на `<html>`. `ThemeProvider` из пакета ставит его сам
  (`light` / `dark` / `system`), но можно переключать и своим кодом — `Toaster` следит за классом.
- Акцент модуля — атрибут `data-module` на корне (`andon`, `maintenance`, `plantReport`, `qrci`,
  `change`, `audits`, `planning`, `projects`, `claims`, `quotation`, `docs`, `drawings`, `infoboards`).
  В React — `ModuleProvider`; во Vue — `document.documentElement.dataset.module = "andon"`.

## Vue 2/3 + Vuetify

```js
// main.js
import "@mgc/ui/tokens.css"
import "@mgc/ui/fonts.css"
import { mgcVuetifyThemes } from "@mgc/ui/vuetify"

// Vuetify 3
createVuetify({ theme: { defaultTheme: "mgcLight", themes: mgcVuetifyThemes } })

// Vuetify 2
import { mgcVuetify2Themes } from "@mgc/ui/vuetify"
new Vuetify({ theme: { themes: mgcVuetify2Themes } })
```

В своих стилях — переменные: `var(--brand)`, `var(--border)`, `var(--module-strong)`.
Цвета модуля для Vuetify-компонентов: `mgcModuleColors.andon.light.strong`.

## Vue + Tailwind v3 (change-management)

```js
// tailwind.config.js
module.exports = {
  presets: [require("@mgc/ui/tailwind-preset")],
  content: ["./src/**/*.{vue,js,ts}"],
}
```

```js
// main.js
import "@mgc/ui/tokens.css"
import "@mgc/ui/fonts.css"
```

Цвета идут через CSS-переменные, поэтому `bg-primary/50` в v3 не сработает — берите `*-soft` токены.

## Figma

Плагин **Tokens Studio** → Load from file → `node_modules/@mgc/ui/dist/figma-tokens.json`
(или файл из витрины). Наборы: `brand`, `core`, `light`, `dark`, `modules`; темы «MGC · светлая» и «MGC · тёмная».

## Установка с сайта витрины (до публикации в Gitea)

Архив пакета лежит на сайте витрины, страница «Установка» показывает готовую команду:

```bash
npm i https://bratz121.github.io/mgc-ui-kit/download/mgc-ui-0.5.0.tgz
```

Там же можно скачать отдельно `tokens.css`, `vuetify.js`, `tailwind-preset.cjs`, `figma-tokens.json`.

## Установка из Gitea

Пакет публикуется в npm-реестр Gitea организации. В проекте рядом с `package.json` — `.npmrc`:

```ini
@mgc:registry=https://<gitea-хост>/api/packages/<организация>/npm/
//<gitea-хост>/api/packages/<организация>/npm/:_authToken=${GITEA_NPM_TOKEN}
```

Токен (`read:package`) — в переменной окружения `GITEA_NPM_TOKEN`, не в репозитории.

## Сборка и публикация (для мейнтейнеров кита)

```bash
npm run build:lib     # packages/ui/dist: JS + типы, styles/theme/tokens/fonts.css, vuetify, preset, figma
npm run pack:lib      # dist-pack/mgc-ui-<версия>.tgz + файлы для скачивания в public/download
npm run build:pages   # витрина для GitHub Pages (base /mgc-ui-kit/) вместе с файлами для скачивания
cd packages/ui && npm publish   # нужен .npmrc с токеном write:package
```

Версия пакета берётся из `package.json` кита. Что изменилось — `CHANGELOG.md`.
Перед публикацией: `npm run build && npm run lint && npm run test:e2e`.
